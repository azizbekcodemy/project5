import rasm from "../imgs/char_1.png"
import rasm1 from "../imgs/char_2.png"
import rasm2 from "../imgs/char_3.png"
import rasm3 from "../imgs/char_4.png"
import qwe from "../imgs/adv_1.png"
import qwe2 from "../imgs/adv_2.png"
import qwe3 from "../imgs/adv_3.png"

import salom1 from "../imgs/featured_1.png"
import salom2 from "../imgs/featured_2.png"
import salom3 from "../imgs/featured_3.png"
import salom4 from "../imgs/featured_4.png"
import salom5 from "../imgs/featured_5.png.webp"
import salom6 from "../imgs/featured_6.png.webp"
import salom7 from "../imgs/featured_7.png.webp"
import salom8 from "../imgs/featured_8.png.webp"
import taaa from "../imgs/banner_2_product.png (1).webp"

import tar1 from "../imgs/new_1.jpg.webp"
import tar2 from "../imgs/new_2.jpg.webp"
import tar3 from "../imgs/new_3.jpg.webp"
import tar4 from "../imgs/new_4.jpg.webp"
import tar5 from "../imgs/new_5.jpg.webp"
import tar6 from "../imgs/new_6.jpg.webp"
import tar7 from "../imgs/new_7.jpg.webp"
import tar8 from "../imgs/new_8.jpg.webp"
import max1 from "../imgs/popular_1.png.webp"
import max2 from "../imgs/popular_2.png.webp"
import max3 from "../imgs/popular_3.png.webp"
import max4 from "../imgs/popular_4.png.webp"
import max5 from "../imgs/popular_5.png.webp"
import rasmq from "../imgs/trends_1.jpg.webp"
import rasmw from "../imgs/trends_2.jpg.webp"
import rasme from "../imgs/trends_3.jpg.webp"
import asd1 from "../../assents/imgs/best_1.png.webp"
import asd2 from "../../assents/imgs/best_2.png.webp"
import asd3 from "../../assents/imgs/best_3.png.webp"
import asd4 from "../../assents/imgs/best_4.png.webp"
import asd5 from "../../assents/imgs/best_5.png.webp"
import asd6 from "../../assents/imgs/best_6.png.webp"


export const Kerak=[
    {
        id:"1",
        img:asd1,
        satr:"Headphones",
        nomi:"Xiaomi Redmi Note 4",
        chekirma:"$225",
        asl:"$300"
    },
    {
        id:"2",
        img:asd2,
        satr:"Headphones",
        nomi:"Xiaomi Redmi Note 4",
        chekirma:"$225",
        asl:"$300"
    },
    {
        id:"3",
        img:asd3,
        satr:"Headphones",
        nomi:"Xiaomi Redmi Note 4",
        chekirma:"$225",
        asl:"$300"
    },
    {
        id:"3",
        img:asd4,
        satr:"Headphones",
        nomi:"Xiaomi Redmi Note 4",
        chekirma:"$225",
        asl:"$300"
    },

    {
        id:"3",
        img:asd5,
        satr:"Headphones",
        nomi:"Xiaomi Redmi Note 4",
        chekirma:"$225",
        asl:"$300"
    },
    {
        id:"3",
        img:asd6,
        satr:"Headphones",
        nomi:"Xiaomi Redmi Note 4",
        chekirma:"$225",
        asl:"$300"
    },
]


export const Kerak1=[
    {
        id:"1",
        img:asd1,
        satr:"Brandom Flowers",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$225"

    },
    {
        id:"1",
        img:tar1,
        satr:"Roberto Sanchez",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$375"

    },
    {
        id:"1",
        img:tar6,
        satr:"Emilia Clarke",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$225"

    },
    {
        id:"1",
        img:salom2,
        satr:"Brandom Flowers",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$375"

    },
    {
        id:"1",
        img:salom5,
        satr:"Roberto Sanchez",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$225"

    },
    {
        id:"1",
        img:asd1,
        satr:"Emilia Clarke",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$225"

    },
    {
        id:"1",
        img:asd1,
        satr:"Brandom Flowers",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$225"

    },
    {
        id:"1",
        img:tar1,
        satr:"Roberto Sanchez",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$375"

    },
    {
        id:"1",
        img:tar6,
        satr:"Emilia Clarke",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$225"

    },
    {
        id:"1",
        img:salom2,
        satr:"Brandom Flowers",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$375"

    },
    {
        id:"1",
        img:salom5,
        satr:"Roberto Sanchez",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$225"

    },
    {
        id:"1",
        img:asd1,
        satr:"Emilia Clarke",
        nomi:"2 day ago",
        chekirma:"Lorem ipsum dolor, sit amet consectetur adipisicing , dicta voluptatem.",
        narx:"$225"

    },
    
]





export const Maxa=[
    {
        id:"1",
        rasm:max1,
        text:"Smartphones & Tables",
        ran:"#EFF6FA"
    },
    {
        id:"1",
        rasm:max2,
        text:"Smartphones & Tables"
    },{
        id:"1",
        rasm:max3,
        text:"Smartphones & Tables",
        ran:"#EFF6FA"

    },{
        id:"1",
        rasm:max4,
        text:"Smartphones & Tables"
    },{
        id:"1",
        rasm:max5,
        text:"Smartphones & Tables",
        ran:"#EFF6FA"

    },
    {
        id:"1",
        rasm:max2,
        text:"Smartphones & Tables"
    },{
        id:"1",
        rasm:max1,
        text:"Smartphones & Tables",
        ran:"#EFF6FA"
    },
    
]


export const MAx =[
    {
        id:"1",
        rasm:rasmq,
        name:"Jump White",
        price:"$379",
        smart:"Smartphones"
    },
    {
        id:"1",
        rasm:rasmw,
        name:"Jump White",
        price:"$379",
        smart:"Smartphones"
    },
    {
        id:"1",
        rasm:rasme,
        name:"Jump White",
        price:"$379",
        smart:"Smartphones"
    },
    {
        id:"1",
        rasm:rasmq,
        name:"Jump White",
        price:"$379",
        smart:"Smartphones"
    },
    {
        id:"1",
        rasm:rasmw,
        name:"Jump White",
        price:"$379",
        smart:"Smartphones"
    },
    {
        id:"1",
        rasm:rasme,
        name:"Jump White",
        price:"$379",
        smart:"Smartphones"
    },
]


export const HOmm=[
    {
        id:"1",
        rasm:rasm,
        name:"Free Delivery",
        price:"from $50"
    },
    {
        id:"2",
        rasm:rasm1,
        name:"Free Delivery",
        price:"from $50"
    },
    {
        id:"3",
        rasm:rasm2,
        name:"Free Delivery",
        price:"from $50"
    },
    {
        id:"4",
        rasm:rasm3,
        name:"Free Delivery",
        price:"from $50"
    },
]


export const dats=[
    {
        id:"1",
        rasm:qwe,
        name:"Trends 2018",
        text:" Lorem ipsum dolor sit amet, consectetur adipiscing Donec et.",
        raz:"19px",
        rang:"#000"
    },

    {
        id:"2",
        rasm:qwe2,
        name:"Trends 2018",
        text:" Lorem ipsum dolor sit amet, consectetur.",
        mt:"-15px",
        mb:"20px",
        sale:"Sale -45%",
        raz:"12px",
        

    },
    {
        id:"3",
        rasm:qwe3,
        name:"Trends 2018",
        text:" Lorem ipsum dolor sit amet, consectetur.",
        raz:"19px",
        rang:"#000"

    },
]



export const salom =[
    {
        id:"1",
        rasm:salom1,
        narx:"$225",
        aksiya:"$300",
        madel:" Huawei MediaPad",
        rang:"red",
        color:"#000000",
        fon:"red",
        cke:"-$25"
    },
    {
        id:"2",
        rasm:salom2,
       rang:"#000000",
        aksiya:"$379",
        madel:" Huawei MediaPad"
    },
    {
        id:"3",
        rasm:salom3,
        rang:"#000000",
       
        aksiya:"$225",
        madel:" Huawei MediaPad"
    },
    {
        id:"4",
        rasm:salom4,
        rang:"#000000",

        aksiya:"$379",
        madel:" Huawei MediaPad",
        fon:"#0e8ce4",
        cke:"new"
    },
    {
        id:"1",
        rasm:salom5,
        narx:"$225",
        aksiya:"$300",
        madel:" Huawei MediaPad",
        fon:"red",
        cke:"-$25"
    },
    {
        id:"2",
        rasm:salom6,
        narx:"$225",
        aksiya:"$300",
        madel:" Huawei MediaPad",
        fon:"#0e8ce4",
        cke:"new"
        
    },
    {
        id:"3",
        rasm:salom7,
        narx:"$225",
        aksiya:"$300",
        madel:" Huawei MediaPad"
    },
    {
        id:"4",
        rasm:salom8,
        narx:"$225",
        aksiya:"$300",
        madel:" Huawei MediaPad"
    },
    

]


export const assa=[
    {
        id:"4",
        rasm:tar1,
        rang:"#000000",

        aksiya:"$379",
        madel:" Huawei MediaPad",
        fon:"#0e8ce4",
        cke:"new"
    }, {
        id:"4",
        rasm:tar2,
        rang:"#000000",

        aksiya:"$379",
        madel:" Huawei MediaPad",
        fon:"#0e8ce4",
        cke:"new"
    }, {
        id:"4",
        rasm:tar3,
        rang:"#000000",

        aksiya:"$379",
        madel:" Huawei MediaPad",
        fon:"#0e8ce4",
        cke:"new"
    }, {
        id:"4",
        rasm:tar4,
        rang:"#000000",

        aksiya:"$379",
        madel:" Huawei MediaPad",
        fon:"#0e8ce4",
        cke:"new"
    }, {
        id:"4",
        rasm:tar5,
        rang:"#000000",

        aksiya:"$379",
        madel:" Huawei MediaPad",
        fon:"#0e8ce4",
        cke:"new"
    }, {
        id:"4",
        rasm:tar6,
        rang:"#000000",

        aksiya:"$379",
        madel:" Huawei MediaPad",
        fon:"#0e8ce4",
        cke:"new"
    }, {
        id:"4",
        rasm:salom7,
        rang:"#000000",

        aksiya:"$379",
        madel:" Huawei MediaPad",
        fon:"#0e8ce4",
        cke:"new"
    }, {
        id:"4",
        rasm:salom8,
        rang:"#000000",

        aksiya:"$379",
        madel:" Huawei MediaPad",
        fon:"#0e8ce4",
        cke:"new"
    },
]


export const Davlat=[
    {
        id:"1", 
        name:"Laptops",
        madel:"MacBook Air 13",
        text:"Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure, atque? Harum, eligendi.",
        rasm:taaa
    },
    {
        id:"2", 
        name:"Laptops",
        madel:"MacBook Air 13",
        text:"Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure, atque? Harum, eligendi.",
        rasm:taaa
    },
    {
        id:"3", 
        name:"Laptops",
        madel:"MacBook Air 13",
        text:"Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure, atque? Harum, eligendi.",
        rasm:taaa
    },


]
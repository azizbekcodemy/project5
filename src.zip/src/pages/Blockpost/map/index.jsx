import rasm from "../../../assents/imgs/blog_4.jpg.webp"
import rasm2 from "../../../assents/imgs/blog_5.jpg.webp"
import rasm3 from "../../../assents/imgs/blog_6.jpg.webp"

export const BBB=[
    {
        id:"1",
        rasm:rasm,
        text:"Etiam leo nibh, consectetur nec orci et, tempus tempus ex",

    },
    {
        id:"2",
        rasm:rasm2,
        text:"Sed viverra pellentesque dictum. Aenean ligula justo, viverra in lacus porttitor",

    },
    {
        id:"3",
        rasm:rasm3,
        text:"In nisl tortor, tempus nec ex vitae, bibendum rutrum mi. Integer tempus nisi",

    },
]